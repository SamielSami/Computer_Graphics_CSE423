from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *


def draw_points():
    glPointSize(1) #pixel size. by default 1 thake
    glBegin(GL_POINTS)
 

    #House
    glVertex2f(100, 100) # X co ord of the point
    glVertex2f(400, 100)
    
    glVertex2f(100, 300) # Y co ord of the point
    glVertex2f(400, 300)
    
    #ROOF
    glVertex2f(250, 400) 
    
    #DOOR
    glVertex2f(140, 200)
    glVertex2f(190, 200)
     
    #WINDOW
    glVertex2f(280, 180)  # X 
    glVertex2f(350, 180)

    glVertex2f(280, 240)  # Y
    glVertex2f(350, 240)

    #glVertex2f(315, 240)

    glEnd()

def drawlines():
    glLineWidth(5)  # pixel size. by default 1 thake
    glBegin(GL_LINES)
   
    glColor3f(0.0, 0.5, 1.0)  # blue house
    glVertex2f(100, 300)   #Y  #startind co ord of the line
    glVertex2f(400, 300)   #  final co ord of the line

    glVertex2f(100, 100)   #X
    glVertex2f(400, 100)

    glVertex2f(100, 100)
    glVertex2f(100, 300)

    glVertex2f(400, 100)
    glVertex2f(400, 300)
    
    #ROOF
    glVertex2f(100, 300) #ROOF
    glVertex2f(250, 400)
    glVertex2f(400, 300) #ROOF
    glVertex2f(250, 400)

    #DOOR
    glVertex2f(140, 200) 
    glVertex2f(190, 200)
    
    glVertex2f(190, 200) #TO BASE
    glVertex2f(190, 100)

    glVertex2f(140, 200) #TO BASE
    glVertex2f(140, 100)

    #window
    glVertex2f(280, 180) #x
    glVertex2f(350, 180)
    glVertex2f(280, 240)
    glVertex2f(350, 240)

    glVertex2f(280, 180) #Y
    glVertex2f(280, 240)
    glVertex2f(350, 180)
    glVertex2f(350, 240)

    #Window lines
    glVertex2f(315, 180)
    glVertex2f(315, 240)

    glVertex2f(280, 210)
    glVertex2f(350, 210)





    glEnd()





def iterate():
    glViewport(0, 0, 500, 500)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(0.0, 500, 0.0, 500, 0.0, 1.0)
    glMatrixMode (GL_MODELVIEW)
    glLoadIdentity()








def showScreen():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    iterate()
    glColor3f(1.0, 1.0, 0.0) #konokichur color set (RGB)
    
    #call the draw methods here
    draw_points()
    drawlines()
  

    #draw_triangle()
    glutSwapBuffers()


glutInit()
glutInitDisplayMode(GLUT_RGBA)
glutInitWindowSize(500, 500) #window size
glutInitWindowPosition(0, 0)
wind = glutCreateWindow(b"House") #window name
glutDisplayFunc(showScreen)

glutMainLoop()