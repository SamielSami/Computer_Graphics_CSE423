from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random

W_Width, W_Height = 500, 500
basket_x = W_Width // 2
basket_width = 80
basket_height = 10
basket_speed = 20

diamond = None
diamond_size = 10
diamond_speed = 2

score = 0
game_over = False

class Diamond:
    def __init__(self, x):
        self.x = x
        self.y = W_Height

    def draw(self):
        glPointSize(diamond_size)
        glBegin(GL_POINTS)
        glColor3f(1.0, 0.0, 1.0)  # Magenta color for diamonds
        glVertex2f(self.x, self.y)
        glEnd()

    def fall(self):
        self.y -= diamond_speed
        if self.y <= 0:
            return False
        return True

def draw_basket(x):
    glColor3f(0.0, 1.0, 0.0)  # Green color for the basket
    glRectf(x - basket_width // 2, 0, x + basket_width // 2, basket_height)

def check_collision(diamond):
    if (basket_height >= diamond.y >= 0 and
        basket_x - basket_width // 2 <= diamond.x <= basket_x + basket_width // 2):
        return True
    return False

def display():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glClearColor(0, 0, 0, 0)

    draw_basket(basket_x)

    if diamond:
        if diamond.fall():
            diamond.draw()
        else:
            global game_over
            game_over = True

    if game_over:
        print(f"Game Over! Score: {score}")
    else:
        print(f"Score: {score}")

    glutSwapBuffers()

def animate():
    global score, diamond, game_over
    if not game_over:
        if diamond and check_collision(diamond):
            score += 1
            diamond = None

        if diamond is None:
            diamond = Diamond(random.randint(0, W_Width))

    glutPostRedisplay()

def keyboardListener(key, x, y):
    global game_over, score, diamond, basket_x
    if key == b'r' and game_over:
        game_over = False
        score = 0
        diamond = None
        basket_x = W_Width // 2

    glutPostRedisplay()

def specialKeyListener(key, x, y):
    global basket_x
    if key == GLUT_KEY_LEFT:
        basket_x = max(basket_x - basket_speed, basket_width // 2)
    if key == GLUT_KEY_RIGHT:
        basket_x = min(basket_x + basket_speed, W_Width - basket_width // 2)

    glutPostRedisplay()

def init():
    glClearColor(0, 0, 0, 0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(0, W_Width, 0, W_Height)

glutInit()
glutInitWindowSize(W_Width, W_Height)
glutInitWindowPosition(0, 0)
glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB)
glutCreateWindow(b"Catch the Diamond!")

init()

glutDisplayFunc(display)
glutIdleFunc(animate)
glutKeyboardFunc(keyboardListener)
glutSpecialFunc(specialKeyListener)

glutMainLoop()
