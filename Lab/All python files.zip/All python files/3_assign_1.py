from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random

W_Width, W_Height = 500, 500
shooter_pos = 0
shooter_radius = 20
projectile_radius = 5
falling_circles = []
projectiles = []
fall_speed = 0.02
misses = 0
score = 0
game_over = False

class Circle:
    def __init__(self, x, y, radius):
        self.x = x
        self.y = y
        self.radius = radius

def draw_circle_midpoint(x_center, y_center, radius):
    x = 0
    y = radius
    p = 1 - radius

    glBegin(GL_POINTS)

    # Plot the initial points
    plot_circle_points(x_center, y_center, x, y)

    while x < y:
        x += 1
        if p < 0:
            p += 2 * x + 1
        else:
            y -= 1
            p += 2 * (x - y) + 1
        plot_circle_points(x_center, y_center, x, y)

    glEnd()

def plot_circle_points(x_center, y_center, x, y):
    # Symmetry to draw all eight octants
    glVertex2f(x_center + x, y_center + y)
    glVertex2f(x_center - x, y_center + y)
    glVertex2f(x_center + x, y_center - y)
    glVertex2f(x_center - x, y_center - y)
    glVertex2f(x_center + y, y_center + x)
    glVertex2f(x_center - y, y_center + x)
    glVertex2f(x_center + y, y_center - x)
    glVertex2f(x_center - y, y_center - x)

def keyboardListener(key, x, y):
    global shooter_pos, projectiles, game_over
    if game_over:
        return

    if key == b'a' and shooter_pos > -W_Width // 2 + shooter_radius:
        shooter_pos -= 10
    elif key == b'd' and shooter_pos < W_Width // 2 - shooter_radius:
        shooter_pos += 10
    elif key == b' ':
        # Shoot a projectile
        projectiles.append(Circle(shooter_pos, -W_Height // 2 + shooter_radius, projectile_radius))

    glutPostRedisplay()

def display():
    glClear(GL_COLOR_BUFFER_BIT)
    glLoadIdentity()

    # Draw shooter
    glColor3f(1, 1, 1)
    draw_circle_midpoint(shooter_pos, -W_Height // 2 + shooter_radius, shooter_radius)

    glutSwapBuffers()

def animate():
    if not game_over:
        glutPostRedisplay()

def init():
    glClearColor(0, 0, 0, 1)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(-W_Width // 2, W_Width // 2, -W_Height // 2, W_Height // 2)
    glViewport(0, 0, W_Width, W_Height)  # Ensure the viewport matches the window size

glutInit()
glutInitWindowSize(W_Width, W_Height)
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
glutCreateWindow(b"Midpoint Circle Test")
init()

glutDisplayFunc(display)
glutIdleFunc(animate)
glutKeyboardFunc(keyboardListener)

glutMainLoop()
