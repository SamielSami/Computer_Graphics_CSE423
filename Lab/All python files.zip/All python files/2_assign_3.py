from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random

W_Width, W_Height = 500, 500
basket_x = W_Width // 2
basket_width = 110
basket_height = 10
basket_speed = 20

diamond = None
diamond_size = 10
diamond_speed = 2
speed_increment_interval = 500
time_counter = 0

score = 0
game_over = False
basket_color = (1.0, 1.0, 1.0)  # Initially white

is_paused = False


class Diamond:
    def __init__(self, x):
        self.x = x
        self.y = W_Height
        self.color = (random.random(), random.random(), random.random())  # Random bright color

    def fall(self):
        self.y -= diamond_speed
        if self.y <= 0:
            return False
        return True


def midpoint_line(x0, y0, x1, y1):
    points = []
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy

    while True:
        points.append((x0, y0))
        if x0 == x1 and y0 == y1:
            break
        e2 = err * 2
        if e2 > -dy:
            err -= dy
            x0 += sx
        if e2 < dx:
            err += dx
            y0 += sy

    return points

def draw_basket(x):
    global basket_color
    top_width = basket_width
    bottom_width = int(basket_width * 0.6)

    left_top = x - top_width // 2
    right_top = x + top_width // 2
    left_bottom = x - bottom_width // 2
    right_bottom = x + bottom_width // 2
    top = basket_height
    bottom = 0

    basket_lines = [
        (left_bottom, bottom, right_bottom, bottom),
        (left_bottom, bottom, left_top, top),
        (right_bottom, bottom, right_top, top),
        (left_top, top, right_top, top)
    ]
    
    for x0, y0, x1, y1 in basket_lines:
        for (px, py) in midpoint_line(x0, y0, x1, y1):
            glVertex2f(px, py)

def draw_diamond(x, y):
    d = diamond_size // 2
    diamond_lines = [
        (x - d, y, x, y + d),
        (x, y + d, x + d, y),
        (x + d, y, x, y - d),
        (x, y - d, x - d, y)
    ]
    
    for x0, y0, x1, y1 in diamond_lines:
        for (px, py) in midpoint_line(x0, y0, x1, y1):
            glVertex2f(px, py)

def draw_arrow_button(x, y, size):
    half_size = size // 2
    arrow_width = size
    arrow_height = size // 2

    # Define the coordinates for the left arrow
    left = x - half_size
    right = x + half_size
    top = y + arrow_height
    bottom = y - arrow_height

    arrow_tip_x = x - arrow_width

    # Lines for the left arrow shape
    lines = [      
        (right, top, arrow_tip_x, y),  
        (arrow_tip_x, y, right, bottom), ]

    
    #glColor3f(0.0, 1.0, 1.0)  # Bright teal color
    for x0, y0, x1, y1 in lines:
        for (px, py) in midpoint_line(x0, y0, x1, y1):
            glVertex2f(px, py)


def draw_play_pause_button(x, y, size, is_paused):
    half_size = size // 2


    if is_paused:
        # Draw a "play" icon (triangle pointing right)
        points = [
            (x - half_size, y - half_size),  # Bottom-left
            (x - half_size, y + half_size),  # Top-left
            (x + half_size, y)               # Tip
        ]

        for i in range(len(points)):
            next_i = (i + 1) % len(points)  # Loop back to the start to complete the triangle
            for (px, py) in midpoint_line(points[i][0], points[i][1], points[next_i][0], points[next_i][1]):
                glVertex2f(px, py)

    else:
        # Draw a "pause" icon (two vertical bars)
        bar_width = size // 4
        left_bar = [
            (x - bar_width, y - half_size),  # Bottom-left of the left bar
            (x - bar_width, y + half_size),  # Top-left of the left bar
            (x - half_size, y + half_size),  # Top-right of the left bar
            (x - half_size, y - half_size)   # Bottom-right of the left bar
        ]

        right_bar = [
            (x + half_size, y - half_size),  # Bottom-left of the right bar
            (x + half_size, y + half_size),  # Top-left of the right bar
            (x + bar_width, y + half_size),  # Top-right of the right bar
            (x + bar_width, y - half_size)   # Bottom-right of the right bar
        ]

        for i in range(len(left_bar)):
            next_i = (i + 1) % len(left_bar)
            for (px, py) in midpoint_line(left_bar[i][0], left_bar[i][1], left_bar[next_i][0], left_bar[next_i][1]):
                glVertex2f(px, py)

        for i in range(len(right_bar)):
            next_i = (i + 1) % len(right_bar)
            for (px, py) in midpoint_line(right_bar[i][0], right_bar[i][1], right_bar[next_i][0], right_bar[next_i][1]):
                glVertex2f(px, py)

   

def draw_cross_button(x, y, size):
    half_size = size // 2
    
    # Coordinates for "X"
    points = [
        (x - half_size, y - half_size, x + half_size, y + half_size),  # Line from bottom-left to top-right
        (x - half_size, y + half_size, x + half_size, y - half_size)   # Line from top-left to bottom-right
    ]
    
    for x0, y0, x1, y1 in points:
        for (px, py) in midpoint_line(x0, y0, x1, y1):
            glVertex2f(px, py)

###########################################################################

def check_collision(diamond):
    if (basket_height >= diamond.y >= 0 and
        basket_x - basket_width // 2 <= diamond.x <= basket_x + basket_width // 2):
        return True
    return False

def display():
    global basket_color
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glClearColor(0, 0, 0, 0)

    glBegin(GL_POINTS)
    glColor3f(*basket_color)
    draw_basket(basket_x)
    
    glColor3f(0.0, 1.0, 1.0)  # Bright teal color
    draw_arrow_button(50, W_Height - 50, 40)

    glColor3f(1.0, 0.64, 0.0)  # Amber color for play/pause button
    draw_play_pause_button(W_Width // 2, W_Height - 50, 40, is_paused)

    glColor3f(1.0, 0.0, 0.0)  # Red color for cross button
    draw_cross_button(W_Width - 50, W_Height - 50, 40)
   
    #if diamond:
        #draw_diamond(0,0)   
    
    if diamond and not is_paused:
        if diamond.fall():
            glColor3f(diamond.color[0], diamond.color[1], diamond.color[2])
            draw_diamond(diamond.x, diamond.y)
        else:
            global game_over
            game_over = True
            basket_color = (1.0, 0.0, 0.0)

    if game_over:
        print(f"Game Over! Score: {score}")
    else:
        print(f"Score: {score}")

    glEnd()
    glutSwapBuffers()

def animate():
    global score, diamond, game_over, time_counter, diamond_speed
    if not is_paused and not game_over:
        if diamond and check_collision(diamond):
            score += 1
            diamond = None

        if diamond is None:
             diamond = Diamond(random.randint(0, W_Width))
        
        time_counter += 1
        if time_counter % speed_increment_interval == 0:
            diamond_speed += 0.5  # Increase the speed incrementally

    glutPostRedisplay()

def mouse(button, state, x, y):
    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        # Convert mouse coordinates to OpenGL coordinates
        y = W_Height - y  # Flip y-axis
        
        # Button boundaries
        button_x = 50
        button_y = W_Height - 50
        button_size = 40
        
        if (button_x - button_size // 2 <= x <= button_x + button_size // 2 and
            button_y - button_size // 2 <= y <= button_y + button_size // 2):
            restart_game()
            print("Starting Over")
        # Play/Pause Button
        elif W_Width // 2 - 20 <= x <= W_Width // 2 + 20 and W_Height - 70 <= y <= W_Height - 30:
            global is_paused
            is_paused = not is_paused
        
        # Cross Button
        elif W_Width - 70 <= x <= W_Width - 30 and W_Height - 70 <= y <= W_Height - 30:
            print(f"Goodbye! Your score: {score}")
            glutLeaveMainLoop()  # Terminate the application

    glutPostRedisplay()

def restart_game():
    global game_over, score, diamond, basket_x, basket_color, diamond_speed, time_counter
    game_over = False
    score = 0
    diamond = None
    basket_x = W_Width // 2
    basket_color = (1.0, 1.0, 1.0)  # Reset basket color to white
    diamond_speed = 2  # Reset diamond speed
    time_counter = 0  # Reset the time counter
    diamond = Diamond(random.randint(0, W_Width))  # Start a new diamond

def keyboardListener(key, x, y):
    global game_over, score, diamond, basket_x, basket_color, diamond_speed, time_counter
    if key == b'r' and game_over:
        restart_game()
        print("Starting Over")

    glutPostRedisplay()

def specialKeyListener(key, x, y):
    global basket_x
    if key == GLUT_KEY_LEFT:
        basket_x = max(basket_x - basket_speed, basket_width // 2)
    if key == GLUT_KEY_RIGHT:
        basket_x = min(basket_x + basket_speed, W_Width - basket_width // 2)

    glutPostRedisplay()

def init():
    glClearColor(0, 0, 0, 0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(0, W_Width, 0, W_Height)



glutInit()
glutInitWindowSize(W_Width, W_Height)
glutInitWindowPosition(0, 0)
glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB)
glutCreateWindow(b"Catch the Diamond!")

init()

glutDisplayFunc(display)
glutIdleFunc(animate)
glutKeyboardFunc(keyboardListener)
glutSpecialFunc(specialKeyListener)
glutMouseFunc(mouse)
glutMainLoop()
