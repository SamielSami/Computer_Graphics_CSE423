from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random
import sys

W_Width, W_Height = 700, 700
circle_radius = 20

# Shooter variables
shooter_x = W_Width // 2
shooter_radius = 15
shooter_speed = 50

# Projectile variables
projectiles = []
projectile_radius = 5
projectile_speed = 20

# Falling circles variables
falling_circles = []
falling_speed = 0.5
falling_circle_radius = 20
missed_circles = 0
score = 0
game_over = False

button_left_pos = (50, W_Height - 50)
button_middle_pos = (W_Width // 2, W_Height - 50)
button_right_pos = (W_Width - 50, W_Height - 50)

button_size = 30

game_paused = False

def midpoint_line(x0, y0, x1, y1):
    points = []
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy

    while True:
        points.append((x0, y0))
        if x0 == x1 and y0 == y1:
            break
        e2 = err * 2
        if e2 > -dy:
            err -= dy
            x0 += sx
        if e2 < dx:
            err += dx
            y0 += sy

    return points


def is_inside_button(x, y, button_center): #check mouse click
    button_x, button_y = button_center
    distance = ((x - button_x) ** 2 + (y - button_y) ** 2) ** 0.5
    return distance < button_size

# Draw the Left Arrow Button
def draw_left_arrow():
    glColor3f(0.0, 1.0, 1.0)  # Teal color
    points = midpoint_line(button_left_pos[0] + button_size, button_left_pos[1],
                           button_left_pos[0] - button_size, button_left_pos[1])
    points += midpoint_line(button_left_pos[0] - button_size, button_left_pos[1],
                            button_left_pos[0], button_left_pos[1] + button_size)
    points += midpoint_line(button_left_pos[0] - button_size, button_left_pos[1],
                            button_left_pos[0], button_left_pos[1] - button_size)
    glBegin(GL_POINTS)
    for x, y in points:
        glVertex2f(x, y)
    glEnd()

# Draw the Play/Pause Button
def draw_play_pause_button():
    glColor3f(1.0, 0.64, 0.0)  # Amber color
    if game_paused:
        # Draw play icon (triangle)
        points = midpoint_line(button_middle_pos[0] - button_size // 2, button_middle_pos[1] - button_size // 2,
                               button_middle_pos[0] + button_size // 2, button_middle_pos[1])
        points += midpoint_line(button_middle_pos[0] - button_size // 2, button_middle_pos[1] + button_size // 2,
                                button_middle_pos[0] + button_size // 2, button_middle_pos[1])
    else:
        # Draw pause icon (two vertical lines)
        points = midpoint_line(button_middle_pos[0] - button_size // 2, button_middle_pos[1] - button_size // 2,
                               button_middle_pos[0] - button_size // 2, button_middle_pos[1] + button_size // 2)
        points += midpoint_line(button_middle_pos[0] + button_size // 4, button_middle_pos[1] - button_size // 2,
                                button_middle_pos[0] + button_size // 4, button_middle_pos[1] + button_size // 2)
    glBegin(GL_POINTS)
    for x, y in points:
        glVertex2f(x, y)
    glEnd()

# Draw the Cross (Exit) Button
def draw_cross_button():
    glColor3f(1.0, 0.0, 0.0)  # Red color
    points = midpoint_line(button_right_pos[0] - button_size // 2, button_right_pos[1] - button_size // 2,
                           button_right_pos[0] + button_size // 2, button_right_pos[1] + button_size // 2)
    points += midpoint_line(button_right_pos[0] - button_size // 2, button_right_pos[1] + button_size // 2,
                            button_right_pos[0] + button_size // 2, button_right_pos[1] - button_size // 2)
    glBegin(GL_POINTS)
    for x, y in points:
        glVertex2f(x, y)
    glEnd()


# Check if a button is clicked


# Define the midpoint circle drawing algorithm
def midpoint_circle(x_center, y_center, radius):
    points = []
    x = 0
    y = radius
    p = 1 - radius

    def draw_circle_points(x_center, y_center, x, y):
        points.extend([(x_center + x, y_center + y), (x_center - x, y_center + y),
                       (x_center + x, y_center - y), (x_center - x, y_center - y),
                       (x_center + y, y_center + x), (x_center - y, y_center + x),
                       (x_center + y, y_center - x), (x_center - y, y_center - x)])

    draw_circle_points(x_center, y_center, x, y)

    while x < y:
        x += 1
        if p < 0:
            p += 2 * x + 1
        else:
            y -= 1
            p += 2 * (x - y) + 1
        draw_circle_points(x_center, y_center, x, y)

    return points

def draw_circle(x_center, y_center, radius):
    glBegin(GL_POINTS)
    for (x, y) in midpoint_circle(x_center, y_center, radius):
        glVertex2f(x, y)
    glEnd()

def draw_shooter():
    glColor3f(0.0, 1.0, 0.0)
    draw_circle(shooter_x, shooter_radius, shooter_radius)

def draw_projectile(projectile):
    glColor3f(1.0, 1.0, 0.0)
    draw_circle(projectile[0], projectile[1], projectile_radius)

def draw_falling_circle(circle):
    glColor3f(1.0, 0.0, 0.0)
    draw_circle(circle[0], circle[1], falling_circle_radius)

def check_collision(circle, projectile):
    dx = circle[0] - projectile[0]
    dy = circle[1] - projectile[1]
    distance = (dx ** 2 + dy ** 2) ** 0.5
    return distance < (falling_circle_radius + projectile_radius)

def display():
    glClear(GL_COLOR_BUFFER_BIT)
    draw_shooter()

    # Draw buttons
    draw_left_arrow()
    draw_play_pause_button()
    draw_cross_button()

    # Draw projectiles
    for projectile in projectiles:
        draw_projectile(projectile)

    # Draw falling circles
    for circle in falling_circles:
        draw_falling_circle(circle)

    glutSwapBuffers()


def animate():
    global projectiles, falling_circles, missed_circles, score, game_over

    if not game_paused and not game_over:
        # Move projectiles
        projectiles = [(x, y + projectile_speed) for x, y in projectiles if y < W_Height]

        # Move falling circles
        new_falling_circles = []
        for circle in falling_circles:
            new_y = circle[1] - falling_speed
            if new_y <= 0:
                missed_circles += 1
                if missed_circles >= 3:
                    game_over = True
                    print("Game Over! Final Score:", score)
                    return
            else:
                new_falling_circles.append((circle[0], new_y))

        falling_circles = new_falling_circles

        # Check for collisions with projectiles
        for projectile in projectiles:
            for circle in falling_circles:
                if check_collision(circle, projectile):
                    projectiles.remove(projectile)
                    falling_circles.remove(circle)
                    score += 1
                    print("Score:", score)
                    break

        # Check if any falling circle hits the shooter
        for circle in falling_circles:
            if check_collision(circle, (shooter_x, shooter_radius)):
                game_over = True
                print("Game Over! A falling circle hit the shooter! Final Score:", score)
                return

        # Spawn a new falling circle randomly at the top
        if random.random() < 0.02:  # Adjust probability for spawning new circles
            falling_circles.append((random.randint(falling_circle_radius, W_Width - falling_circle_radius), W_Height))

    glutPostRedisplay()
def keyboard(key, x, y):
    global shooter_x, projectiles

    if key == b'a':
        shooter_x = max(shooter_x - shooter_speed, shooter_radius)

    if key == b'd':
        shooter_x = min(shooter_x + shooter_speed, W_Width - shooter_radius)

    if key == b' ' and not game_over:
        projectiles.append((shooter_x, shooter_radius + shooter_radius))

def mouse(button, state, x, y):
    global game_paused, game_over, missed_circles, score, falling_speed, falling_circles, projectiles

    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        y = W_Height - y  # Convert GLUT y-coordinate to OpenGL's system

        # Check for the Left Arrow/Restart Button
        if is_inside_button(x, y, button_left_pos):
            print("Starting Over")
            score = 0
            missed_circles = 0
            game_paused = False
            game_over = False
            falling_circles = []
            projectiles = []
            #falling_speed = 2

        # Check for the Play/Pause Button
        elif is_inside_button(x, y, button_middle_pos):
            game_paused = not game_paused

        # Check for the Cross/Exit Button
        elif is_inside_button(x, y, button_right_pos):
            print(f"Goodbye! Final Score: {score}")
            glutLeaveMainLoop() #terminates



def init():
    glClearColor(0, 0, 0, 0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluOrtho2D(0, W_Width, 0, W_Height)

# Setup OpenGL and GLUT
glutInit()
glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE)
glutInitWindowSize(W_Width, W_Height)
glutCreateWindow(b"Shoot The Circles!")
glutDisplayFunc(display)
glutIdleFunc(animate)
glutKeyboardFunc(keyboard)
glutMouseFunc(mouse)
init()
glutMainLoop()
