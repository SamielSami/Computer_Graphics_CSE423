from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import random

# Global variables for rain control
rain_enabled = False
rain_x = 400
rain_y = 850
rain_bend = 0
background_color = [1.0, 1.0, 1.0]  # Initial background color is white
raindrop_color = [0.0, 0.0, 0.0]  # Initial raindrop color is black

def draw_points(x, y):
    glPointSize(5)
    glBegin(GL_POINTS)
    glVertex2f(x, y)
    glEnd()

def draw_points1(x, y):
    glPointSize(4)
    glBegin(GL_POINTS)
    coordinate_points = 50
    for i in range(coordinate_points):
        x = random.randint(1, 1000)
        y = random.randint(1, 1000)
        glColor3f(*raindrop_color)  # Raindrop color
        glVertex2f(x, y)
    glEnd()

def draw_lines():
    glLineWidth(3.22)
    glBegin(GL_LINES)

    # outer structure
    glColor3f(0.0, 0.5, 1.0)  # blue house
    glVertex2f(100, 200)
    glVertex2f(500, 200)

    glVertex2f(100, 200)
    glVertex2f(100, 500)

    glVertex2f(500, 200)
    glVertex2f(500, 500)

    glVertex2f(100, 500)
    glVertex2f(500, 500)

    # door
    glColor3f(0.0, 0.5, 1.0)  # Blue door
    glVertex2f(200, 200)
    glVertex2f(200, 300)

    glVertex2f(200, 200)
    glVertex2f(300, 200)

    glVertex2f(300, 200)
    glVertex2f(300, 300)

    glVertex2f(200, 300)
    glVertex2f(300, 300)


    # window
    glColor3f(0.0, 0.5, 1.0)  # Blue window border
    glVertex2f(320, 380)
    glVertex2f(400, 380)

    glVertex2f(320, 380)
    glVertex2f(320, 440)

    glVertex2f(400, 380)
    glVertex2f(400, 440)

    glVertex2f(320, 440)
    glVertex2f(400, 440)

    glEnd()

def background():
    glClearColor(*background_color, 1.0)  # Set background color
    glClear(GL_COLOR_BUFFER_BIT)


def draw_triangle():
    glBegin(GL_TRIANGLES)
    glColor3f(0.0, 0.5, 1.0) #blue house
    glVertex2f(100, 500)
    glVertex2f(500, 500)
    glVertex2f(290, 770)
    glEnd()

def iterate():
    glViewport(0, 0, 700, 900)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    glOrtho(0.0, 700, 0.0, 900, 0.0, 1.0)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()

def handle_mouse(button, state, x, y):
    global rain_enabled

    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        rain_enabled = not rain_enabled
    elif button == GLUT_RIGHT_BUTTON and state == GLUT_DOWN:
        rain_enabled = False

def handle_special_keys(key, x, y):
    global rain_bend

    if key == GLUT_KEY_LEFT:
        rain_bend -= 1
        print("Rain bent towards left")
    elif key == GLUT_KEY_RIGHT:
        rain_bend += 1
        print("Rain bent towards right")

def handle_keyboard(key, x, y):
    global background_color, raindrop_color

    if key == b'd':
        # Change the background to white and raindrop color to black
        background_color = [1.0, 1.0, 1.0]  # White background
        raindrop_color = [1.0, 0.0, 1.0]  # Black raindrop color
        print("Nightmode: Off")
    elif key == b'n':
        # Change the background to black and raindrop color to white
        background_color = [0.0, 0.0, 0.0]  # Black background
        raindrop_color = [1.0, 1.0, 1.0]  # White raindrop color
        print("Nightmode: On")

def showScreen():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    iterate()

    background()
    draw_lines()

    draw_points(290, 240)

    if rain_enabled:
        draw_points1(400 - rain_bend, 850)

    draw_triangle()
    glutSwapBuffers()

def rain_timer(value):
    glutTimerFunc(200, rain_timer, 0)
    glutPostRedisplay()

glutInit()
glutInitDisplayMode(GLUT_RGBA)
glutInitWindowSize(1000, 1000)
glutInitWindowPosition(250, 0)
wind = glutCreateWindow(b"Task1:Lab01")
glutDisplayFunc(showScreen)
glutMouseFunc(handle_mouse)
glutSpecialFunc(handle_special_keys)
glutKeyboardFunc(handle_keyboard)
glutTimerFunc(100, rain_timer, 0)  # Start rain timer
glutMainLoop()